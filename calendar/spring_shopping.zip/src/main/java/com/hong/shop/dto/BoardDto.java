package com.hong.shop.dto;

public class BoardDto {
	private int board_pk;
	private int user_fk;
	private String title;
	private String content;
	private String bd_time;
	private int hit;
	private int grp;
	private int num;
	private int depth;
	private String user_id; // 외래키 연결용
	
	
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public int getDepth() {
		return depth;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getBoard_pk() {
		return board_pk;
	}
	public void setBoard_pk(int board_pk) {
		this.board_pk = board_pk;
	}
	public int getUser_fk() {
		return user_fk;
	}
	public void setUser_fk(int user_fk) {
		this.user_fk = user_fk;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getBd_time() {
		return bd_time;
	}
	public void setBd_time(String bd_time) {
		this.bd_time = bd_time;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public int getGrp() {
		return grp;
	}
	public void setGrp(int grp) {
		this.grp = grp;
	}
	
	
}
