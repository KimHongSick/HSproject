package com.hong.shop.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hong.shop.dto.BoardDto;
import com.hong.shop.dto.UserDto;

public interface ShopMapper {
	public String login_check(UserDto user);
	public UserDto getOneUser(UserDto user);
	public List<BoardDto> getAllBoardByPage(@Param("startboard") int startboard,@Param("pagesize") int pagesize);
	public void board_insert(BoardDto bDto);
	public void board_grp_update(int board_pk);
	public BoardDto getOneBoard(int board_pk);
	public void board_update(BoardDto bDto);
	public void update_hit(int board_pk);
	public UserDto update_userCheck(int user_fk);
	public int getPageCount();
	public void board_reply_update(BoardDto bDto);
	public List<BoardDto> getReply(int board_pk);
	public void board_delete(int board_pk);
}
