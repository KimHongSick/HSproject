package com.hong.shop.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hong.shop.dto.BoardDto;
import com.hong.shop.dto.UserDto;
import com.hong.shop.service.ShopService;

@Controller
public class ShopController {
	
	int pageSize = 5;
	@Autowired
	ShopService ss;
	
	@RequestMapping("main")
	public String main(HttpSession session, Model model){
		UserDto lgUser = (UserDto) session.getAttribute("lgUser");
		if(lgUser != null){
			model.addAttribute("lgUser", lgUser);
		}
		model.addAttribute("lgUser", session.getAttribute("lgUser"));
		return "main";
	}
	
	@RequestMapping("login")
	public String login_form(Model model,
			@RequestParam(value="user_fk", required=false, defaultValue="0") int user_fk,
			@RequestParam(value="checkType", required=false, defaultValue="0") int checkType,
			@RequestParam(value="board_pk", required=false, defaultValue="0") int board_pk){
		model.addAttribute("user_fk", user_fk);
		model.addAttribute("checkType", checkType);
		model.addAttribute("board_pk", board_pk);
		return "login";
	}
	
	@RequestMapping("login_action")
	public String login_action(Model model,HttpSession session,
			UserDto user,
			@RequestParam(value="user_fk", required=false) int user_fk,
			@RequestParam(value="checkType", required=false) int checkType,
			@RequestParam(value="board_pk", required=false) int board_pk){
		int lgResult = 0;
		String msg = "";
		
		if(checkType==0){ // 기본 로그인할 때
			lgResult = ss.login_check(user);
			
			System.out.println("아이디 : " + user.getUser_id());
			System.out.println("비밀번호 : " + user.getUser_pw());
			
			if(lgResult==1){
				session.setAttribute("lgUser", ss.getOneUser(user));
			}else if(lgResult == 0){
				msg = "비밀번호가 틀렸습니다.";
			}else if(lgResult == -1){
				msg = "존재하지 않는 회원입니다.";
			}
			
			
		}else{ //수정하기 버튼 클릭 시 해당 게시판의 유저인지 검사
			lgResult = ss.update_userCheck(user_fk, user);
			
			if(lgResult == 1){ // 권한 인증 성공
				lgResult = 2;
			}else if(lgResult==-2){ // DB에 존재하는 회원이지만 해당 게시물에 대한 권한이 없음
				msg = "해당 게시판에 권한이 없습니다";
			}else if(lgResult == -1){ 
				msg = "존재하지 않는 회원입니다.";
			}else if(lgResult == 0){
				msg = "비밀번호가 틀렸습니다.";
			}
		}
		
		model.addAttribute("msg", msg);
		model.addAttribute("lgResult", lgResult);
		
		// 로그인 실패시 input 값 유지하기 위해
		model.addAttribute("board_pk", board_pk); 
		model.addAttribute("user_fk", user_fk);
		model.addAttribute("checkType", checkType);
		return "login";
	}
	
	@RequestMapping("logout")
	public String logout(HttpSession session){
		session.invalidate();
		return "redirect:main";
	}
	
	
	@RequestMapping("board_form")
	public String board_form(Model model, HttpSession session,
			@RequestParam(value="page", required=false, defaultValue="1") int page){
		List<BoardDto> board = ss.getAllBoardByPage(page);
		
		for(int i = 0; i < board.size(); i++){ // 게시물 번호 매기기
			board.get(i).setNum((page - 1)*pageSize + i + 1);
		}
		model.addAttribute("lgUser", (UserDto) session.getAttribute("lgUser"));
		model.addAttribute("board", board);
		model.addAttribute("pageCount", ss.getPageCount()); // 페이지 갯수
		model.addAttribute("crtPage", page); // 현재 페이지
		return "board/boardform";
	}
	
	@RequestMapping("board_view")
	public String board_view(Model model,
			@RequestParam(value="board_pk", required=false) int board_pk){
		model.addAttribute("oneboard", ss.getOneBoard(board_pk));
		ss.update_hit(board_pk);
		
		List<BoardDto> reBoard = ss.getReply(board_pk);
		
		model.addAttribute("reBoard", reBoard);
		return "board/boardview";
	}
	
	@RequestMapping("board_write_form")
	public String board_write(Model model, HttpSession session,
			@RequestParam(value="board_pk", required=false, defaultValue="0") int board_pk){
		
		if(board_pk!=0){ // 게시물을 수정할 때
			
			model.addAttribute("oneboard", ss.getOneBoard(board_pk));
		}
		model.addAttribute("lgUser", (UserDto) session.getAttribute("lgUser"));
		return "board/boardwrite";
	}
	
	@RequestMapping("board_write_action") // 수정과 추가 화면을 같이 사용, board_pk 값이 0이면 추가/ 0을 제외한 값이면 수정
	public String board_write_insert(BoardDto bDto,
			@RequestParam(value="reply", required=false) int reply){ // reply가 1이면 리플 게시물 추가, 0 이면 일반 게시물
		int board_pk = bDto.getBoard_pk();
		
		if(board_pk==0){
			ss.board_insert(bDto, reply); // reply가 0 이면 기본 게시물 insert
		}else{
			ss.board_update(bDto);
		}
		return "redirect:board_form";
	}
	
	@RequestMapping("board_reply_form")
	public String board_reply_form(Model model, HttpSession session,
			@RequestParam("parent_pk") int parent_pk){
		BoardDto parBoard = ss.getOneBoard(parent_pk);
		
		model.addAttribute("lgUser", (UserDto) session.getAttribute("lgUser"));
		model.addAttribute("parBoard", parBoard);
		return "board/board_reply";
	}
	
	@RequestMapping("board_reply_action")
	public String board_reply_action(Model model, BoardDto bDto,
			@RequestParam(value="reply", required=false) int reply){
		ss.board_insert(bDto, reply); // reply가 1 이면 리플 게시물 insert
		return "redirect:board_form";
	}
	
	@RequestMapping("board_delete")
	public String board_delete(@RequestParam(value="board_pk") int board_pk){
		ss.board_delete(board_pk);
		return "redirect:board_form";
	}
}
