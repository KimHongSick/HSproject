package com.hong.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hong.shop.dao.ShopMapper;
import com.hong.shop.dto.BoardDto;
import com.hong.shop.dto.UserDto;

@Service
public class ShopService {
	
	@Autowired
	ShopMapper sm;
	
	public int login_check(UserDto user){
		int result = 0;
		String user_pw = sm.login_check(user); // 입력한 아이디에 해당하는 비번
		String input_pw = user.getUser_pw(); // 사용자가 입력한 비밀번호
		
		if(user_pw==null){
			result = -1;
		}else if(user_pw.equals(input_pw)){
			result = 1;
		}else if(!user_pw.equals(input_pw)){
			result = 0;
		}
		return result;
	}
	
	
	public UserDto getOneUser(UserDto user){
		
		return sm.getOneUser(user);
	}
	
	int pagesize = 5;
	public List<BoardDto> getAllBoardByPage(int page){
		int startboard = (page-1) * pagesize;
		return sm.getAllBoardByPage(startboard,pagesize);
	}
	
	public void board_insert(BoardDto bDto, int reply){
		sm.board_insert(bDto);
		int board_pk = bDto.getBoard_pk();
		if(reply == 0){ // 게시물 등록
			sm.board_grp_update(board_pk); // 추가 된 게시물의 기본키를 grp에 대입
		}else{ // 리플 달기
			sm.board_reply_update(bDto); 
		}
	}
	
	public void board_update(BoardDto bDto){
		sm.board_update(bDto);
	}
	
	public BoardDto getOneBoard(int board_pk){
		
		return sm.getOneBoard(board_pk);
	}
	
	public void update_hit(int board_pk){
		sm.update_hit(board_pk);
	}
	
	public int update_userCheck(int user_fk,UserDto user){
		int result = 0;
		UserDto userByboard = sm.update_userCheck(user_fk); // 게시물 권한 사용자의 정보 
		String input_pw = user.getUser_pw(); // 사용자가 입력한 비밀번호
		String user_pw = sm.login_check(user); // 입력한 아이디에 해당하는 비밀번호
		
		if(user_pw==null){
			result = -1; // 해당 아이디가 존재하지 않음
		}else if(user_pw.equals(input_pw)){ // 아이디와 비밀번호 일치
			if(user.getUser_id().equals(userByboard.getUser_id())){
				result = 1;
			}else{
				result = -2;
			}
		}else if(!user_pw.equals(input_pw)){
			result = 0;
		}
		return result;
	}
	
	public int getPageCount(){
		int allBoard = sm.getPageCount(); // depth가 0 인 모든 게시물의 count
		int pageCount = (int)Math.ceil(allBoard/(double)pagesize);
		
		return pageCount;
	}
	
	public List<BoardDto> getReply(int board_pk){
		
		return sm.getReply(board_pk);
	}
	
	public void board_delete(int board_pk){
		sm.board_delete(board_pk);
	}
}
