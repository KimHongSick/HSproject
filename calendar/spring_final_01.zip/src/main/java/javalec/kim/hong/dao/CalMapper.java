package javalec.kim.hong.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import javalec.kim.hong.dto.EventDto;
import javalec.kim.hong.dto.SrchDto;
import javalec.kim.hong.dto.UserDto;

public interface CalMapper {
	
	public List<EventDto> eventlist(@Param("searchdate") String searchdate, // OneMonth
			@Param("searchtext") String searchtext, @Param("type") int type 
			,@Param("user_pk") int user_pk);
	public void insertEvent(EventDto eDto); // 일정 추가
	public List<EventDto> yearEvent(@Param("crtYear") String crtYear,@Param("user_fk") int user_fk); //년도별 일정
	public EventDto oneEvent(int event_id); // 특정 일정
	public void updateEvent(EventDto eDto); // 일정 수정
	public void deleteEvent(int event_id); // 일정 삭제
	public List<EventDto> dayEvent(@Param("searchday") String searchday, @Param("user_fk") int user_fk);  // 하루단위 일정
	
	public String usercheck(UserDto uDto); // user_id와 일치하는 pwd 를 출력
	public UserDto getOneUser(String user_id); 
	public String insert_id_check(UserDto uDto);//회원가입을 하면서 입력한 id가 존재하는지 검사
	public void insertUser(UserDto uDto);
	
	public List<EventDto> allEvent(int user_pk);
	public List<EventDto> srchEvent(SrchDto sDto);
}
