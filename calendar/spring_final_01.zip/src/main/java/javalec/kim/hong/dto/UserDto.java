package javalec.kim.hong.dto;

public class UserDto { // 데이터베이스의 user 테이블 DTO
	private int user_pk; // 사용자 pk
	private String user_id, pwd, name; // 아이디, 비밀번호, 사용자명 
	
	public int getUser_pk() {
		return user_pk;
	}
	public void setUser_pk(int user_pk) {
		this.user_pk = user_pk;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
