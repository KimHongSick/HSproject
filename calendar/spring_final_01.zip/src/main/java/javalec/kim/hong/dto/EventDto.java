package javalec.kim.hong.dto;

public class EventDto { // 데이터 베이스에 event 테이블 DTO
	private int event_id, user_fk, category; // 이벤트 pk, 사용자 pk의 외래키, 이벤트 종류
	private String content,title; //내용, 제목
	private String s_date, e_date; //시작날짜, 종료날짜
	private String kind_name; // category 테이블의 종류 이름
	
	
	public String getKind_name() {
		return kind_name;
	}
	public void setKind_name(String kind_name) {
		this.kind_name = kind_name;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public int getUser_fk() {
		return user_fk;
	}
	public void setUser_fk(int user_fk) {
		this.user_fk = user_fk;
	}
		public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getEvent_id() {
		return event_id;
	}
	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getS_date() {
		return s_date;
	}
	public void setS_date(String s_date) {
		this.s_date = s_date;
	}
	public String getE_date() {
		return e_date;
	}
	public void setE_date(String e_date) {
		this.e_date = e_date;
	}
}
