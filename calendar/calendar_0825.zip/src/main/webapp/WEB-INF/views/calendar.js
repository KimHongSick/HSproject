/*------------- login_form.jsp 시작 -------------*/
/* 로그인.jsp value 검사 */
function value_check() {
	var user_id = document.frm.user_id;
	var pwd = document.frm.pwd;

	if (user_id.value.trim().length == 0) {
		alert("아이디를 입력해주세요.");
		user_id.focus();
		return false;
	}

	if (pwd.value.trim().length == 0) {
		alert("비밀번호를 입력해주세요.");
		pwd.focus();
		return false;
	}

	return true;
}
/* 회원가입.jsp로 이동 */
function go_insertUser() {
	location.href = "insertUserForm";
}
/*------------- login_form.jsp 끝 -------------*/

/*------------- insert_user.jsp 시작 -------------*/
function insert_user_check() {
	var name = document.frm.name;
	var user_id = document.frm.user_id;
	var pwd = document.frm.pwd;
	var pwd_ok = document.frm.pwd_ok;

	if (name.value.trim().length == 0 || name.value == null) {
		alert("이름을 입력해주세요.");
		name.focus();
		return false;
	}
	if (user_id.value.trim().length == 0) {
		alert("아이디를 입력해주세요.");
		user_id.focus();
		return false;
	}
	if (pwd.value.trim().length == 0) {
		alert("비밀번호를 입력해주세요.");
		pwd.focus();
		return false;
	}
	if (pwd_ok.value.trim().length == 0) {
		alert("비밀번호 확인을 입력해주세요.");
		pwd_ok.focus();
		return false;
	}
	if (pwd_ok.value != pwd.value) {
		alert("비밀번호와 비밀번호 확인이 다릅니다.")
		pwd.value = "";
		pwd_ok.value = "";
		pwd.focus();
		return false;
	}

	return true;
}
/*------------- insert_user.jsp 끝 -------------*/

/*------------- insert_event.jsp, update_event.jsp 시작 -------------*/
function event_check(){ // 종료날이 시작일보다 앞에 있을때 submit 이 안되도록 
		var title = document.getElementById("title");
		var content = document.getElementById("content");
		var s_date_el = document.getElementById("s_date");
		var e_date_el = document.getElementById("e_date");
	
	if(title.value.trim().length==0){
		alert("제목을 입력해주세요");
		title.focus();
		return false;
	}
	if(content.value.trim().length==0){
		alert("내용을 입력해주세요");
		content.focus();
		return false;
	}
			
	if(s_date_el.value > e_date_el.value){
		alert("종료날이 시작날보다 빠릅니다.");
		s_date_el.value = e_date_el.value;
		return false;		
	}else{
		return true;
	}
}
/*------------- insert_event.jsp,  update_event.jsp 끝 -------------*/

/*------------- all_month.jsp 시작 -------------*/
function goOneMonth(y,m){
	if(confirm(y + "년 " + m + "월 로 이동하시겠습니까?")){
		location.href="OneMonth?tyear="+y+"&tmonth="+m;
	}else{
		return false;
	}
	return true;
}
/*------------- all_month.jsp 끝 -------------*/

/*------------- all_event.jsp 시작-------------*/

function date_check(){
	var srch_str = document.frm.srch_str;
	var srch_end = document.frm.srch_end;
	
	if(srch_str.value=="" || srch_str.value==null
			||srch_end.value=="" ||srch_end.value==null){
		alert("검색날짜를 입력해주세요");
		return false
	}
	
	if(srch_str.value>srch_end.value){
		alert("종료날이 시작날보다 빠릅니다.\n다시 입력해주세요.");
		return false;
	}else{
		return true;
	}
}
/*------------- all_event.jsp 끝-------------*/