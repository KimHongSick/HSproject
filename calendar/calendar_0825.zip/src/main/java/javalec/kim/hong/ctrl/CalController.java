package javalec.kim.hong.ctrl;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javalec.kim.hong.dto.EventDto;
import javalec.kim.hong.dto.SrchDto;
import javalec.kim.hong.dto.UserDto;
import javalec.kim.hong.service.CalService;

@Controller
public class CalController {
	
	@Autowired
	CalService cs;
	
	 //시작 화면
	@RequestMapping(value = "intro")
	public String intro_form() {
		
		return "calendar/intro";
	}
	
	//로그인 화면
	@RequestMapping(value = "loginForm")
	public String login_form() {
		
		return "calendar/login_form";
	}
	
	//로그인 화면에서 로그인 버튼 클릭 시
	@RequestMapping(value = "loginAction",method=RequestMethod.POST)
	public String login_action(Model md, UserDto uDto, HttpSession session) {
		int result = cs.usercheck(uDto); // id 와 pwd를 통해 결과값을 int로 구분(성공 : 1, 실패 : -1, 존재x : 0)해서 result에 저장
		String msg = null;
		String page = null;
		
		if(result == 0){ // DB에 회원이 존재 하지 않을 때
			msg = "회원이 존재하지않습니다.";
			page = "calendar/login_form";
		}else if(result == 1){ // 로그인 성공
			session.setAttribute("login_user", cs.getOneUser(uDto.getUser_id())); //id에 해당하는 user 정보
			page = "redirect:MainView";
		}else if(result == -1){ // 비밀번호 틀렸을 때
			msg = "비밀번호가 틀렸습니다.";
			page = "calendar/login_form";
		}
		
		md.addAttribute("msg", msg);
		return page;
	}
	
	// 로그아웃 버튼 클릭 시
	@RequestMapping("logoutAction")
	public String logout_action(HttpSession session){
		session.removeAttribute("login_user"); // session에 저장되어있던 사용자 Dto 제거
		
		return "calendar/login_form";
	}
	
	//메인화면
	@RequestMapping("MainView")
	public String main(Model md){
		Date date = new Date(); // 오늘의 날짜로 객체 생성
		SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy년 MM월 dd일 시간 : hh:mm:ss");
		String formattedDate = simpleFormat.format(date); // 오늘의 날짜를 지정된 형태로 변경
		
		md.addAttribute("date", formattedDate);
		return "calendar/main";
	}
	
	// 한달 화면
	@RequestMapping("OneMonth")
	public String one_month_form(Model md, HttpSession session,
			@RequestParam(value = "tyear", required = false) int tyear,
			@RequestParam(value = "tmonth", required = false) int tmonth,
			@RequestParam(value = "searchtext", required = false) String searchtext,
			@RequestParam(value = "type", required = false, defaultValue = "0") int type){
		
		String searchdate = "";
		
		UserDto user = (UserDto) session.getAttribute("login_user"); // 로그인 되어있던 사용자 정보
		int user_pk = user.getUser_pk(); 
		
		//one_month.jsp 에서 ◀,▶ 버튼 클릭 시 12월 혹은 1월에서 다음해로 넘어가도록 설정
		if(tmonth == 13){ 
			tyear += 1;
			tmonth = 1;
		} else if(tmonth == 0){
			tyear -= 1;
			tmonth = 12;
		}
		
		//한달 페이지에 그에 해당하는 년도와 월의 일정을 DB에서 가져오기 위한 변수 
		searchdate = tyear + "-" + String.format("%02d", tmonth); // 2017-8 => 2017-08
		
		md.addAttribute("type", type);
		md.addAttribute("tyear", tyear);
		md.addAttribute("tmonth", tmonth);
		md.addAttribute("event", cs.eventlist(searchdate, searchtext, type, user_pk));
		return "calendar/one_month";
	}
	
	// 년도별 달력 화면
	@RequestMapping(value="AllMonth", method=RequestMethod.GET)
	public String all_month_form(Model md, HttpSession session,
			@RequestParam(value="year", required=false) String year){
		Date date = new Date();
		SimpleDateFormat yearFomat = new SimpleDateFormat("yyyy");
		String crtYear = null;
		
		if(year==null||year.equals("")){ // 년도별 달력에서 받아온 year값이 없으면 현재 년도를 기본값으로 위해 설정
			crtYear = yearFomat.format(date);
		}else{
			crtYear = year;
		}
		
		int user_fk = ((UserDto)session.getAttribute("login_user")).getUser_pk();
		
		md.addAttribute("crtyear", crtYear); //
		md.addAttribute("Yearevent", cs.yearEvent(crtYear, user_fk)); // 년도와 사용자 pk를 통해 해당 일정을 return
		return "calendar/all_month";
	}
	
	//일정 추가 화면
	@RequestMapping("insertEventForm")
	public String insert_event(Model md,
			@RequestParam(value = "tyear", required = false) int tyear,
			@RequestParam(value = "tmonth", required = false) int tmonth,
			@RequestParam(value = "dNum", required = false) int dNum){
		
		String month, day; 
		
		month = String.format("%02d", tmonth); // 무조건 형태를 2자리로 고정 (ex. 1 => 01, 5 => 05, 10 => 10) 
		day = String.format("%02d", dNum);		
		
		md.addAttribute("tyear", tyear);
		md.addAttribute("tmonth", month);
		md.addAttribute("dNum", day);
			
		return "calendar/insert_event";
	}
	
	//일정 추가 기능
	@RequestMapping("insertEventAction")
	public String insert_event_action(Model md,EventDto eDto, HttpSession session,
			@RequestParam(value = "tyear", required = false) int tyear,
			@RequestParam(value = "tmonth", required = false) int tmonth,
			@RequestParam(value="category", required = false) int category){
		
		eDto.setUser_fk(((UserDto)session.getAttribute("login_user")).getUser_pk()); // DTO에 로그인한 사용자 pk를 user_fk에 대입
		cs.insertEvent(eDto);
		
		md.addAttribute("tyear", tyear);
		md.addAttribute("tmonth", tmonth);
		
		return "redirect:OneMonth"; // redirect로 RequestMapping의 value가 OneMonth인 곳으로
	}
	
	// 수정 화면
	@RequestMapping("updateEventForm")
	public String update_event_form(Model md,
			@RequestParam(value = "event_id", required = false) int event_id,
			@RequestParam(value = "tyear", required = false) int tyear,
			@RequestParam(value = "tmonth", required = false) int tmonth){
		
		md.addAttribute("event", cs.oneEvent(event_id)); //해당 event의 pk를 통해 일정을 수정 화면에 return
		md.addAttribute("tyear", tyear);
		md.addAttribute("tmonth", tmonth);
		
		return "calendar/update_event";
	}
	
	// 수정 기능
	@RequestMapping(value="updateEventAction",method=RequestMethod.POST)
	public String update_event_action(Model md,EventDto eDto,
			@RequestParam(value = "tyear", required = false) int tyear,
			@RequestParam(value = "tmonth", required = false) int tmonth,
			@RequestParam(value="category", required = false) int category){
		
		cs.updateEvent(eDto); 
		
		md.addAttribute("tyear", tyear);
		md.addAttribute("tmonth", tmonth);
		return "redirect:OneMonth";
	}
	
	//일정 삭제
	@RequestMapping("deleteEvent")
	public String delete_event_action(Model md,
			@RequestParam(value = "event_id", required = false) int event_id,
			@RequestParam(value = "tyear", required = false) int tyear,
			@RequestParam(value = "tmonth", required = false) int tmonth){
		
		cs.deleteEvent(event_id); // event의 pk를 통해 그에 해당하는 일정 삭제
		
		md.addAttribute("tyear", tyear);
		md.addAttribute("tmonth", tmonth);
		return "redirect:OneMonth";
	}
	
	//일별로 구분한 페이지
	@RequestMapping("oneday")
	public String oneday_form(Model md, HttpSession session,
			@RequestParam(value = "tyear", required = false) int tyear,
			@RequestParam(value = "tmonth", required = false) int tmonth,
			@RequestParam(value = "dNum", required = false) int dNum){
		String searchday ="";
		String month = String.format("%02d", tmonth);
		String Num = String.format("%02d", dNum);
		searchday = tyear + "-" + month + "-" + Num; //해당 날짜를 mybatis에서 select하기 위해 설정
		int user_fk = ((UserDto)session.getAttribute("login_user")).getUser_pk();
		
		md.addAttribute("tyear", tyear);
		md.addAttribute("tmonth", tmonth);
		md.addAttribute("dNum", dNum);
		md.addAttribute("day_event", cs.dayEvent(searchday, user_fk));
		return "calendar/one_day";
	}
	
	//회원가입 화면
	@RequestMapping("insertUserForm")
	public String insert_user_form(Model md){
		md.addAttribute("result", -1); //회원가입할 아이디를 검사할 result 초기값 지정
		
		return "calendar/insert_user";
	}
	
	//회원가입 기능
	@RequestMapping(value="insertUserAction", method=RequestMethod.POST)
	public String insert_user_action(UserDto uDto,Model md){
		
		System.out.println("insert Name : " + uDto.getName());
		int result = cs.insert_id_check(uDto);
		
		if(result==1){ // 가입하려는 id가 DB에 존재하지 않을 경우 result에 1로 리턴
							//존재하는 경우 0 
			cs.insertUser(uDto);
		}
		md.addAttribute("uDto", uDto);
		md.addAttribute("result", result);
		return "calendar/insert_user";
	}

	//분할 화면
	@RequestMapping("frame")
	public String frame(Model md, @RequestParam(value="screen") int screen){
		md.addAttribute("screen", screen);
		return "frame";
	}
	
	//프레임 우측화면
	@RequestMapping("srchEventForm")
	public String srchEvent_form(SrchDto sDto, HttpSession session, Model md){
		int user_pk = ((UserDto) session.getAttribute("login_user")).getUser_pk();
		sDto.setUser_pk(user_pk);
		
		md.addAttribute("allEvent", cs.allEvent(user_pk)); // 로그인한 사용자의 모든 일정 return
		md.addAttribute("srchEvent", cs.srchEvent(sDto)); // 검색한 날짜 사이에 모든 일정을 return
		md.addAttribute("srchdate", sDto);
		return "calendar/all_event";
	}
	
}
