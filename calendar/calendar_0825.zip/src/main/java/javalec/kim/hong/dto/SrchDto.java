package javalec.kim.hong.dto;

public class SrchDto {
	private String srch_str, srch_end;
	private int user_pk;
	
	public String getSrch_str() {
		return srch_str;
	}
	public void setSrch_str(String srch_str) {
		this.srch_str = srch_str;
	}
	public String getSrch_end() {
		return srch_end;
	}
	public void setSrch_end(String srch_end) {
		this.srch_end = srch_end;
	}
	public int getUser_pk() {
		return user_pk;
	}
	public void setUser_pk(int user_pk) {
		this.user_pk = user_pk;
	}
	
}
