package javalec.kim.hong.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javalec.kim.hong.dao.CalMapper;
import javalec.kim.hong.dto.EventDto;
import javalec.kim.hong.dto.SrchDto;
import javalec.kim.hong.dto.UserDto;

@Service
public class CalService {
	
	@Autowired
	CalMapper cm;
	
	//한달 단위 일정을 return
	public List<EventDto> eventlist(String searchdate, String searchtext, int type, int user_pk){
		System.out.println("검색할 값 : " + searchtext);
		return cm.eventlist(searchdate, searchtext, type, user_pk);
	}
	
	//일정 추가
	public void insertEvent(EventDto eDto){
		cm.insertEvent(eDto);
	}
	
	//년도별 일정을 return
	public List<EventDto> yearEvent(String crtYear, int user_fk){
		return cm.yearEvent(crtYear, user_fk);
	}
	
	//한개의 일정
	public EventDto oneEvent(int event_id){
		return cm.oneEvent(event_id);
	}
	
	//일정 수정
	public void updateEvent(EventDto eDto){
		cm.updateEvent(eDto);
	}
	
	//일정 삭제
	public void deleteEvent(int event_id){
		cm.deleteEvent(event_id);
	}
	
	//일단위 일정 return
	public List<EventDto> dayEvent(String searchday, int user_fk){
		return cm.dayEvent(searchday,user_fk);
	}
	
	//사용자가 존재하는지 비밀번호가 맞는지 검사
	public int usercheck(UserDto uDto){
		
		String pwd = cm.usercheck(uDto); // 입력한 id에 매칭하는 pwd
		System.out.println("pwd : " + pwd);
		
		int rtn = 0;
		if(pwd==null){
			rtn = 0; // 회원이 존재 하지 않을 때
		}else if(pwd.equals(uDto.getPwd())){
			rtn = 1; // 로그인 성공
		}else if(!pwd.equals(uDto.getPwd())){
			rtn = -1; // 비밀번호가 틀렸을 경우
		}
		return rtn;
	}
	
	//아이디에 해당하는 user 정보를 모두 return
	public UserDto getOneUser(String user_id){
		System.out.println("user_pk : "+cm.getOneUser(user_id));
		return cm.getOneUser(user_id);
	}
	
	//로그인 할려는 아이디가 DB에 존재하는지 검사
	public int insert_id_check(UserDto uDto){
		if(cm.insert_id_check(uDto)==null){
			return 1; //  존재하지 않을 경우-> 1;
		}
		return 0; // 존재하는 경우 -> 0;
	}
	
	//회원가입 
	public void insertUser(UserDto uDto){
		cm.insertUser(uDto);
	}
	
	//모든 일정  
	public List<EventDto> allEvent(int user_pk){
		return cm.allEvent(user_pk);
	}
	//날짜로 검색
	public List<EventDto> srchEvent(SrchDto sDto){
		return cm.srchEvent(sDto);
	}
}
